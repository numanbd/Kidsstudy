# Kids Study Helper

A free Android prompt-helper app for children. It does **not** use paid AI API. It creates a smart study prompt and opens ChatGPT, Gemini, or Copilot in the browser.

## Features

- Select student class
- Select subject
- Select help mode
- Write a question/topic
- Add question photo reminder
- Generate child-friendly smart prompt
- Copy prompt automatically before opening AI
- Open ChatGPT / Gemini / Copilot
- Share prompt
- Save recent prompt history locally

## Why this app is free to use

This app does not call OpenAI/Gemini API. It only prepares the prompt. The user can paste the prompt into free AI services.

## How to build

1. Download or clone this project.
2. Open the folder in Android Studio.
3. Let Gradle sync finish.
4. Click **Run** to install on phone, or **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important

- If Android Studio says `compileSdk 35 not installed`, install SDK 35 from SDK Manager or change `compileSdk` and `targetSdk` in `app/build.gradle` to the SDK installed on your computer.
- Internet permission is not needed because this app only opens websites by browser Intent.
- No personal data is sent by this app itself.

## Suggested child-safe usage

Children should use AI with a parent. The app is designed to help parents prepare better questions for study support.
