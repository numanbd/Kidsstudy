package com.fuad.kidsstudyhelper;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private Spinner classSpinner, subjectSpinner, modeSpinner;
    private EditText questionInput;
    private TextView imageInfo, promptOutput, historyOutput;
    private Uri selectedImageUri;
    private static final int PICK_IMAGE = 101;
    private static final String PREFS = "study_helper_prefs";
    private static final String HISTORY = "history";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        loadHistory();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28));
        root.setBackgroundColor(Color.parseColor("#F6F8FC"));
        scroll.addView(root);

        TextView title = text("Kids Study Helper", 26, true, "#202124");
        root.addView(title);
        TextView subtitle = text("No paid API. Make smart prompts, then open ChatGPT / Gemini / Copilot.", 14, false, "#5F6368");
        subtitle.setPadding(0, dp(6), 0, dp(16));
        root.addView(subtitle);

        LinearLayout card = card();
        root.addView(card);

        classSpinner = spinner(new String[]{"Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8"});
        subjectSpinner = spinner(new String[]{"Math", "English", "Science", "Bangla", "General Knowledge", "Islamic Studies", "Computer"});
        modeSpinner = spinner(new String[]{"Step-by-step teacher", "Short answer", "Practice questions", "Exam preparation", "Explain in Bangla + English", "Only hints, not full answer"});

        card.addView(label("Student Class")); card.addView(classSpinner);
        card.addView(label("Subject")); card.addView(subjectSpinner);
        card.addView(label("Help Mode")); card.addView(modeSpinner);

        card.addView(label("Question / Topic"));
        questionInput = new EditText(this);
        questionInput.setHint("Example: Explain division with easy examples / paste question here");
        questionInput.setMinLines(5);
        questionInput.setGravity(Gravity.TOP);
        questionInput.setTextSize(16);
        questionInput.setBackgroundResource(getResources().getIdentifier("edit_bg", "drawable", getPackageName()));
        questionInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.addView(questionInput, new LinearLayout.LayoutParams(-1, -2));

        Button imageBtn = button("Add Question Photo", false);
        imageBtn.setOnClickListener(v -> pickImage());
        card.addView(imageBtn);
        imageInfo = text("No image selected. If you use a photo, paste/upload it manually after opening AI.", 13, false, "#5F6368");
        imageInfo.setPadding(0, dp(4), 0, dp(10));
        card.addView(imageInfo);

        Button generate = button("Make Smart Prompt", true);
        generate.setOnClickListener(v -> generatePrompt());
        card.addView(generate);

        promptOutput = text("Your smart prompt will appear here.", 15, false, "#202124");
        promptOutput.setPadding(dp(12), dp(12), dp(12), dp(12));
        promptOutput.setBackgroundResource(getResources().getIdentifier("edit_bg", "drawable", getPackageName()));
        LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, -2);
        outLp.setMargins(0, dp(12), 0, dp(12));
        card.addView(promptOutput, outLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        card.addView(actions);

        Button copy = button("Copy Prompt", false);
        copy.setOnClickListener(v -> copyPrompt());
        actions.addView(copy);
        Button share = button("Share Prompt", false);
        share.setOnClickListener(v -> sharePrompt());
        actions.addView(share);
        Button chatgpt = button("Open ChatGPT", true);
        chatgpt.setOnClickListener(v -> openUrl("https://chatgpt.com/"));
        actions.addView(chatgpt);
        Button gemini = button("Open Gemini", false);
        gemini.setOnClickListener(v -> openUrl("https://gemini.google.com/"));
        actions.addView(gemini);
        Button copilot = button("Open Copilot", false);
        copilot.setOnClickListener(v -> openUrl("https://copilot.microsoft.com/"));
        actions.addView(copilot);

        LinearLayout historyCard = card();
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(16), 0, 0);
        root.addView(historyCard, hp);
        historyCard.addView(text("Recent Prompt History", 20, true, "#202124"));
        historyOutput = text("No history yet.", 14, false, "#5F6368");
        historyOutput.setPadding(0, dp(10), 0, dp(10));
        historyCard.addView(historyOutput);
        Button clear = button("Clear History", false);
        clear.setOnClickListener(v -> clearHistory());
        historyCard.addView(clear);

        setContentView(scroll);
    }

    private void generatePrompt() {
        String cls = classSpinner.getSelectedItem().toString();
        String subject = subjectSpinner.getSelectedItem().toString();
        String mode = modeSpinner.getSelectedItem().toString();
        String question = questionInput.getText().toString().trim();
        if (question.isEmpty() && selectedImageUri == null) {
            toast("Please write a question or add a photo.");
            return;
        }
        StringBuilder p = new StringBuilder();
        p.append("You are a kind tutor for an English medium student.\n");
        p.append("Student level: ").append(cls).append(".\n");
        p.append("Subject: ").append(subject).append(".\n");
        p.append("Mode: ").append(mode).append(".\n\n");
        p.append("Rules:\n");
        p.append("1. Use very simple English and Bangla explanation.\n");
        p.append("2. Do not only give the final answer. Teach step by step.\n");
        p.append("3. Use small examples suitable for a child.\n");
        p.append("4. Ask 2 short practice questions at the end.\n");
        p.append("5. If the child is wrong, correct gently.\n\n");
        if (selectedImageUri != null) {
            p.append("I have a question photo. First read the image carefully, then explain it.\n");
        }
        p.append("Question/topic:\n").append(question.isEmpty() ? "Please solve/explain the attached photo." : question);
        promptOutput.setText(p.toString());
        saveHistory(cls, subject, question.isEmpty() ? "Photo question" : question, p.toString());
        toast("Smart prompt created.");
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            imageInfo.setText("Photo selected. After opening AI, upload this photo there too.");
        }
    }

    private void copyPrompt() {
        String txt = promptOutput.getText().toString();
        if (txt.startsWith("Your smart")) { toast("Generate prompt first."); return; }
        ClipboardManager cb = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("study_prompt", txt));
        toast("Prompt copied.");
    }

    private void sharePrompt() {
        String txt = promptOutput.getText().toString();
        if (txt.startsWith("Your smart")) { toast("Generate prompt first."); return; }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, txt);
        startActivity(Intent.createChooser(send, "Share prompt"));
    }

    private void openUrl(String url) {
        copyPrompt();
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(i);
    }

    private void saveHistory(String cls, String subject, String question, String prompt) {
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(HISTORY, "[]"));
            JSONObject obj = new JSONObject();
            obj.put("time", new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date()));
            obj.put("title", cls + " • " + subject);
            obj.put("question", question.length() > 90 ? question.substring(0, 90) + "..." : question);
            obj.put("prompt", prompt);
            JSONArray newArr = new JSONArray();
            newArr.put(obj);
            for (int x=0; x<Math.min(arr.length(), 9); x++) newArr.put(arr.getJSONObject(x));
            sp.edit().putString(HISTORY, newArr.toString()).apply();
            loadHistory();
        } catch(Exception e) { e.printStackTrace(); }
    }

    private void loadHistory() {
        if (historyOutput == null) return;
        try {
            JSONArray arr = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(HISTORY, "[]"));
            if (arr.length() == 0) { historyOutput.setText("No history yet."); return; }
            StringBuilder sb = new StringBuilder();
            for (int i=0; i<arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                sb.append(i+1).append(". ").append(o.getString("title")).append("\n")
                        .append(o.getString("time")).append("\n")
                        .append(o.getString("question")).append("\n\n");
            }
            historyOutput.setText(sb.toString());
        } catch(Exception e) { historyOutput.setText("History loading error."); }
    }

    private void clearHistory() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(HISTORY).apply();
        loadHistory();
        toast("History cleared.");
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundResource(getResources().getIdentifier("card_bg", "drawable", getPackageName()));
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        return l;
    }

    private TextView label(String s) {
        TextView v = text(s, 14, true, "#202124");
        v.setPadding(0, dp(14), 0, dp(6));
        return v;
    }

    private Spinner spinner(String[] items) {
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        sp.setAdapter(adapter);
        return sp;
    }

    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? Color.WHITE : Color.parseColor("#263A8B"));
        b.setBackgroundResource(getResources().getIdentifier(primary ? "primary_button" : "secondary_button", "drawable", getPackageName()));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String s, int size, boolean bold, String color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(Color.parseColor(color));
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return v;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
}
